import datetime, difflib, hashlib, json, os, re, shutil, signal, subprocess, tarfile, tempfile, time, traceback
from pathlib import Path
from urllib.request import urlopen

ROOT=Path('/mnt/d/CyberSecurity/CS5298 BlockChain/FinalProject')
SOURCE=ROOT/'main/holderproof'
RUN=ROOT/'test-records'/datetime.datetime.now(datetime.timezone.utc).astimezone(datetime.timezone(datetime.timedelta(hours=8))).strftime('acceptance-20261124-%H%M%S')
RUN.mkdir(parents=True,exist_ok=False)
PROJECT=RUN/'isolated-project'
PORTS={8545:18545,10087:20087,11087:21087,12087:22087,13087:23087,8080:18080,8081:18081,8082:18082,8083:18083}
ENV=dict(os.environ)
ENV['PATH']=str(Path.home()/'.shakenup/bin')+':'+str(Path.home()/'.cargo/bin')+':'+ENV['PATH']
ENV['CARGO_TARGET_DIR']=str(Path.home()/'.cache/holderproof/target')
ENV['PYTHONUNBUFFERED']='1'
summary={'scope':'Fresh single-host 3-of-4 acceptance on Windows with Ubuntu WSL2','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'port_map':PORTS,'public_chain_transactions_sent':0,'stages':[]}

def save():
    (RUN/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
def get(url):
    with urlopen(url,timeout=10) as r:return json.load(r)
def stage(name,args,timeout=1200):
    print('START',name,flush=True)
    record={'stage':name,'command':args,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    summary['stages'].append(record);save()
    start=time.monotonic()
    with (RUN/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=PROJECT,env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    record.update(exit_code=result.returncode,elapsed_seconds=round(time.monotonic()-start,2));save()
    print('END',name,result.returncode,record['elapsed_seconds'],flush=True)
    if result.returncode:raise RuntimeError(name+' failed; inspect '+name+'.log')

try:
    summary['source_commit']=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()
    summary['source_status_before']=subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True)
    if summary['source_status_before']:raise RuntimeError('Source has uncommitted changes; snapshot needs explicit handling')
    with (RUN/'source.tar').open('wb') as out:
        subprocess.run(['git','-C',str(SOURCE),'archive','HEAD'],stdout=out,check=True)
    PROJECT.mkdir()
    with tarfile.open(RUN/'source.tar') as archive:archive.extractall(PROJECT,filter='data')
    summary['original_web_before']=get('http://127.0.0.1:8765/api/snapshot')
    (RUN/'source-reference.json').write_text(json.dumps({'commit':summary['source_commit'],'status':summary['source_status_before']},indent=2)+'\n')
    pattern=re.compile(r'\b('+ '|'.join(map(str,PORTS))+r')\b')
    diffs=[]
    for path in sorted((PROJECT/'scripts').iterdir()):
        if path.suffix not in ('.py','.sh'):continue
        before=path.read_text();after=pattern.sub(lambda m:str(PORTS[int(m[0])]),before)
        if before!=after:
            path.write_text(after)
            diffs.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(path.relative_to(PROJECT)),tofile=str(path.relative_to(PROJECT))))
    (RUN/'isolation.patch').write_text(''.join(diffs))
    ldk=RUN/'ldk-isolated'
    (ldk/'scripts/lib').mkdir(parents=True)
    installed=Path.home()/'.shakenup/ldk/scripts'
    shutil.copy2(installed/'localnet.sh',ldk/'scripts/localnet.sh')
    before=(installed/'lib/localnet.sh').read_text()
    after=before.replace('_LOCALNET_API_BASE=10087','_LOCALNET_API_BASE=20087').replace('_LOCALNET_UPC_BASE=10080','_LOCALNET_UPC_BASE=20080').replace('_LOCALNET_ANVIL_PORT=8545','_LOCALNET_ANVIL_PORT=18545')
    (ldk/'scripts/lib/localnet.sh').write_text(after)
    (RUN/'ldk-isolation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='installed/scripts/lib/localnet.sh',tofile='isolated/scripts/lib/localnet.sh')))
    ENV['LYQUOR_LDK_DIR']=str(ldk)
    ENV['LOCALNET_WORK_DIR']=tempfile.mkdtemp(prefix='holderproof-acceptance-20261124-')
    summary['localnet_runtime_directory']=ENV['LOCALNET_WORK_DIR']
    summary['run_directory']=str(RUN);save();print('EVIDENCE',RUN,flush=True)
    stage('environment',['bash','scripts/setup-env.sh','--check'])
    stage('baseline',['make','check'])
    stage('guest-tests',['make','guest-test'])
    stage('demo',['bash','scripts/reproduce-step4.sh'])
    shutil.copytree(PROJECT/'.run/step4',RUN/'initial-demo',ignore=shutil.ignore_patterns('*.log'))
    stage('historical',['python3','scripts/verify_historical_balance.py'])
    stage('gate-actions',['python3','scripts/verify_e3.py'])
    stage('committee-availability',['python3','scripts/verify_committee_availability.py'])
    stage('epoch',['python3','scripts/verify_epoch_checkpoints.py'])
    epoch=get('http://127.0.0.1:18081/api/epoch-checkpoints')
    events=json.loads((PROJECT/'fixtures/transfers.json').read_text())
    checks=[]
    for ep in epoch['checkpoints']:
        block=ep['checkpoint']['to_block'];expected=sum(e['block_number']<=block for e in events)
        assert ep['checkpoint']['event_count']==expected
        assert 3<=len(set(ep['signer_ids']))==len(ep['signer_ids'])<=4
        checks.append({'block':block,'event_count':expected,'signer_count':len(ep['signer_ids']),'distinct_signers':True})
    assert [c['block'] for c in checks]==[250,500,750,1000]
    summary['epoch_independent_checks']=checks;save()
    stage('credit',['python3','scripts/verify_credit.py'])
    stage('sepolia',['python3','scripts/verify_sepolia.py'])
    # Keep raw RPC receipts for every recorded Gate action and revocation.
    result=json.loads((PROJECT/'.run/acceptance/e3-results.json').read_text())
    receipts={}
    for item in result:
        for key,value in item.items():
            if (key.endswith('_tx') or key=='tx') and isinstance(value,str) and value.startswith('0x'):
                raw=subprocess.check_output(['cast','receipt',value,'--json','--rpc-url','http://127.0.0.1:18545'],env=ENV,text=True,timeout=20)
                receipts[value]=json.loads(raw)
    (RUN/'gate-transaction-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    shutil.copytree(PROJECT/'.run/acceptance',RUN/'results')
    summary['all_stages_passed']=True
except Exception as exc:
    summary['all_stages_passed']=False;summary['error']=str(exc)
    (RUN/'failure.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    # Stop only processes recorded by this isolated project's fresh launcher.
    cleanup=[]
    state=PROJECT/'.run/step4/state.env'
    if state.exists():
        values={}
        for line in state.read_text().splitlines():
            key,value=line.split('=',1)
            if value.isdigit():values[key]=int(value)
        for key in ('SERVE_INDEXER_PID','SERVE_CONSUMER_PID','SERVE_GOVERNANCE_PID'):
            pid=values.get(key)
            if pid:
                try:
                    cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes()
                    if b'shaker' in cmd and b'1808' in cmd:os.kill(pid,signal.SIGTERM);cleanup.append(key)
                except (FileNotFoundError,ProcessLookupError):pass
        pid=values.get('LOCALNET_PID')
        if pid:
            try:
                cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes()
                if str(RUN).encode() in cmd and os.getpgid(pid)==pid:
                    os.killpg(pid,signal.SIGCONT);os.killpg(pid,signal.SIGTERM);cleanup.append('isolated localnet group')
            except (FileNotFoundError,ProcessLookupError):pass
    summary['cleanup']=cleanup
    runtime=Path(ENV.get('LOCALNET_WORK_DIR',str(RUN/'localnet-runtime')))
    if runtime.is_dir():
        for file in runtime.rglob('*'):
            if file.is_file() and file.suffix in ('.log','.toml'):
                dest=RUN/'runtime-logs'/file.relative_to(runtime)
                dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest)
    try:summary['original_web_after']=get('http://127.0.0.1:8765/api/snapshot')
    except Exception as e:summary['original_web_after_error']=str(e)
    summary['source_status_after']=subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True)
    summary['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print('FINISHED',RUN,'PASS',summary.get('all_stages_passed'),flush=True)

