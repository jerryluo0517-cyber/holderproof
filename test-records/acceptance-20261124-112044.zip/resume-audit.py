import ast,datetime,json,os,shutil,signal,subprocess,tempfile,time,traceback
from pathlib import Path
from urllib.request import urlopen

ROOT=Path('/mnt/d/CyberSecurity/CS5298 BlockChain/FinalProject')
SOURCE=ROOT/'main/holderproof'
RUN=ROOT/'test-records/acceptance-20261124-112044'
PROJECT=RUN/'isolated-project'
summary=json.loads((RUN/'summary.json').read_text())
shutil.copy2(RUN/'summary.json',RUN/'attempt-before-solc-install.json')
shutil.copy2(RUN/'historical.log',RUN/'historical-offline-failure.log')
shutil.copy2(RUN/'demo.log',RUN/'demo-first.log')
summary['prior_setup_failures']=[x for x in summary['stages'] if x.get('exit_code',0)!=0]
summary['stages']=[x for x in summary['stages'] if x.get('exit_code',0)==0]
summary.pop('error',None);summary.pop('finished_at',None)
summary['all_stages_passed']=False
ENV=dict(os.environ)
ENV['PATH']=str(Path.home()/'.shakenup/bin')+':'+str(Path.home()/'.cargo/bin')+':'+ENV['PATH']
ENV['CARGO_TARGET_DIR']=str(Path.home()/'.cache/holderproof/target')
ENV['PYTHONUNBUFFERED']='1'
ENV['LYQUOR_LDK_DIR']=str(RUN/'ldk-isolated')
ENV['LOCALNET_WORK_DIR']=tempfile.mkdtemp(prefix='holderproof-acceptance-20261124-')
summary['localnet_runtime_directory']=ENV['LOCALNET_WORK_DIR']
tree=ast.parse((ROOT.parent/'tmp/acceptance_audit_20261124.py').read_text())
functions=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('save','get','stage')],type_ignores=[])
exec(compile(functions,'audit-helpers','exec'))
try:
    stage('solidity-build',['forge','build','--root',str(PROJECT/'evm'),'--offline'])
    stage('demo',['bash','scripts/reproduce-step4.sh'])
    shutil.copytree(PROJECT/'.run/step4',RUN/'initial-demo',ignore=shutil.ignore_patterns('*.log'),dirs_exist_ok=True)
    stage('historical',['python3','scripts/verify_historical_balance.py'])
    stage('gate-actions',['python3','scripts/verify_e3.py'])
    stage('committee-availability',['python3','scripts/verify_committee_availability.py'])
    stage('epoch',['python3','scripts/verify_epoch_checkpoints.py'])
    epoch=get('http://127.0.0.1:18081/api/epoch-checkpoints')
    events=json.loads((PROJECT/'fixtures/transfers.json').read_text())
    checks=[]
    for ep in epoch['checkpoints']:
        block=ep['checkpoint']['to_block'];expected=sum(e['block_number']<=block for e in events)
        assert ep['checkpoint']['event_count']==expected
        assert 3<=len(set(ep['signer_ids']))==len(ep['signer_ids'])<=4
        checks.append({'block':block,'event_count':expected,'signer_count':len(ep['signer_ids']),'distinct_signers':True})
    assert [c['block'] for c in checks]==[250,500,750,1000]
    summary['epoch_independent_checks']=checks;save()
    stage('credit',['python3','scripts/verify_credit.py'])
    stage('sepolia',['python3','scripts/verify_sepolia.py'])
    result=json.loads((PROJECT/'.run/acceptance/e3-results.json').read_text())
    receipts={}
    for item in result:
        for key,value in item.items():
            if (key.endswith('_tx') or key=='tx') and isinstance(value,str) and value.startswith('0x'):
                receipts[value]=json.loads(subprocess.check_output(['cast','receipt',value,'--json','--rpc-url','http://127.0.0.1:18545'],env=ENV,text=True,timeout=20))
    (RUN/'gate-transaction-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    shutil.copytree(PROJECT/'.run/acceptance',RUN/'results',dirs_exist_ok=True)
    summary['all_stages_passed']=True
except Exception as exc:
    summary['error']=str(exc);(RUN/'failure-after-resume.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    cleanup=[]
    state=PROJECT/'.run/step4/state.env'
    if state.exists():
        values={k:int(v) for k,v in (line.split('=',1) for line in state.read_text().splitlines()) if v.isdigit()}
        for key in ('SERVE_INDEXER_PID','SERVE_CONSUMER_PID','SERVE_GOVERNANCE_PID'):
            pid=values.get(key)
            if pid:
                try:
                    cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes()
                    if b'shaker' in cmd and b'1808' in cmd:os.kill(pid,signal.SIGTERM);cleanup.append(key)
                except (FileNotFoundError,ProcessLookupError):pass
        pid=values.get('LOCALNET_PID')
        if pid:
            try:
                cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes()
                if str(RUN).encode() in cmd and os.getpgid(pid)==pid:
                    os.killpg(pid,signal.SIGCONT);os.killpg(pid,signal.SIGTERM);cleanup.append('isolated localnet group')
            except (FileNotFoundError,ProcessLookupError):pass
    summary['cleanup']=cleanup
    for file in Path(ENV['LOCALNET_WORK_DIR']).rglob('*'):
        if file.is_file() and file.suffix in ('.log','.toml'):
            dest=RUN/'runtime-logs'/file.relative_to(ENV['LOCALNET_WORK_DIR']);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest)
    summary['original_web_after']=get('http://127.0.0.1:8765/api/snapshot')
    summary['source_status_after']=subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True)
    summary['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print('FINISHED',RUN,'PASS',summary['all_stages_passed'],flush=True)
