import datetime, hashlib, json, re, shutil, sys, tarfile, zipfile
from pathlib import Path

root=Path(r'D:\CyberSecurity\CS5298 BlockChain')
run=root/'FinalProject/test-records'/sys.argv[1]
s=json.loads((run/'summary.json').read_text())
assert s['all_stages_passed'],s.get('error')
assert all(item['exit_code']==0 for item in s['stages'])
project=run/'isolated-project'
results=run/'results'
cert=json.loads((run/'initial-demo/certificate.json').read_text())
gates=json.loads((run/'initial-demo/gate-cases.json').read_text())
evm=json.loads((results/'historical-balances.json').read_text())
e3=json.loads((results/'e3-results.json').read_text())
sep=json.loads((results/'sepolia-certificate.json').read_text())
assert cert['balance']=='62685' and cert['status']=='Finalized'
assert 3<=len(set(cert['signer_ids']))==len(cert['signer_ids'])<=4
assert all(g['queryHash']==cert['query_hash'] for g in gates)
assert evm['transfer_count']==308 and len(evm['checks'])==18
availability=[e for e in e3 if e['case']=='committee availability']
assert [x['certified_while_paused'] for x in availability]==[True,False]
assert len(availability[0]['paused_ports'])==1 and len(availability[1]['paused_ports'])==2
baseline=(run/'baseline.log').read_text()
guest=(run/'guest-tests.log').read_text()
assert 'All 9 checks passed.' in baseline and 'Ran 6 tests' in baseline
assert '21 passed; 0 failed' in guest and '15 passed; 0 failed' in guest
assert 'repeated query is idempotent' in (run/'demo.log').read_text()
# Verify that port isolation did not change Rust application code or input fixtures.
unchanged={}
with tarfile.open(run/'source.tar') as archive:
    for member in archive.getmembers():
        if member.isfile() and (member.name.endswith('.rs') or member.name.startswith('fixtures/')):
            original=archive.extractfile(member).read()
            assert (project/member.name).read_bytes()==original,member.name
            unchanged[member.name]=hashlib.sha256(original).hexdigest()
(run/'application-and-fixture-hashes.json').write_text(json.dumps(unchanged,indent=2)+'\n')
report={'source_commit':s['source_commit'],'fixture_checks':9,'python_tests':6,'rust_guest_tests':{'indexer':21,'gate_core':15},
 'balance':{'amount':cert['balance'],'signer_count':len(cert['signer_ids']),'query_hash':cert['query_hash'],'both_gates_reuse_query':True,'repeat_query_identical':True},
 'evm':{'transfer_logs':evm['transfer_count'],'historical_reads':len(evm['checks'])},
 'gate_actions':e3,'epochs':s['epoch_independent_checks'],
 'sepolia':{'block':sep['block_number'],'event_count':sep['checkpoint']['event_count'],'window_net_wei':sep['balance'],'signer_count':len(sep['signer_ids'])},
 'original_web_unchanged':s['original_web_before']==s['original_web_after'],
 'source_worktree_unchanged':s['source_status_before']==s['source_status_after']=='',
 'all_rust_and_fixture_files_unchanged':True}
assert report['original_web_unchanged'] and report['source_worktree_unchanged']
(run/'verified-results.json').write_text(json.dumps(report,indent=2)+'\n')
# Retain complete node and proxy logs, excluding database contents and development keys.
logs=run/'runtime-logs/step4';logs.mkdir(parents=True,exist_ok=True)
for file in (project/'.run/step4').glob('*.log'):shutil.copy2(file,logs/file.name)
shutil.copy2(root/'tmp/acceptance_audit_20261124.py',run/'run-audit.py')
shutil.copy2(root/'tmp/resume_acceptance_20261124.py',run/'resume-audit.py')
shutil.copy2(__file__,run/'verify-and-package.py')
first=root/'FinalProject/test-records/acceptance-20261124-111721'
if first.exists():
    attempt=run/'earlier-setup-failure';attempt.mkdir(exist_ok=True)
    for name in ('summary.json','failure.txt','demo.log'):
        if (first/name).exists():shutil.copy2(first/name,attempt/name)
    errors=first/'localnet-runtime/node0/lyquor.log'
    if errors.exists():shutil.copy2(errors,attempt/'node0.log')
readme=f'''# HolderProof acceptance reproduction evidence

Date: 24 November 2026 (Asia/Shanghai)
Source commit: {s['source_commit']}
Result: all {len(s['stages'])} recorded stages passed.

The tests ran on one Windows host using Ubuntu WSL2, four Lyquor processes and a
separate Anvil backend. This is not a native Windows Lyquor runtime or a deployment
on four independently hosted machines. The existing Web demo was unchanged.

## Verified observations

- 9 fixture checks, 6 Python tests, 21 Indexer and 15 Gate Core guest tests passed.
- Alice at fixture block 1000: 62685, {len(cert['signer_ids'])} distinct signers;
  identical certificate on repeated query; both Gates reused its query hash.
- Local Anvil: 308 Transfer logs and 18 historical balanceOf reads matched the
  Python fixture reference. This checks synthetic fixture replay, not Ethereum Mainnet.
- Both Gate action suites passed threshold, caller identity, duplicate, configuration
  permission and revocation checks. Transaction receipts are included, but Anvil
  success alone is not proof that a Lyquid action committed; the scripts also check state.
- One paused member: certification succeeded. Two paused members: no certificate
  during {availability[1]['observation_seconds']} seconds measured by the test. Recovery
  succeeded. This is a bounded process-pause test, not a proof for every network fault.
- Epoch event counts: 89 / 172 / 255 / 308. Individual signer counts and full
  checkpoint objects are retained in results/epoch-checkpoints.json.
- Sepolia captured snapshot: {sep['checkpoint']['event_count']} events, end block
  {sep['block_number']}, {len(sep['signer_ids'])} signers, {sep['balance']} wei of WETH
  window net transfer amount. This is not the holder's complete historical balance.
  This run replays the captured data; it does not freshly fetch public-chain logs.
- Credit quotes and Bob's wash-window parameter comparison passed in credit.log.

## Evidence and reproduction

summary.json records every command, time and exit status. verified-results.json is
checked against the raw result files. The top-level stage logs preserve stdout/stderr;
results/ holds certificates, history reconciliation, action cases and checkpoints.
gate-transaction-receipts.json contains the E3 action and revocation receipts.
source.tar is the unmodified Git snapshot. isolation.patch changes only script ports;
ldk-isolation.patch changes the installed launcher port bases. Rust application and
fixture hashes are checked against source.tar. No scoring, quorum or validation rules
were changed. The pack includes the runner used for this session; its source paths
must be adjusted on another machine. The standard repository acceptance entry point
remains scripts/run-3of4-acceptance.sh and requires its default ports to be free.

The separate test used node APIs 20087/21087/22087/23087, Anvil 18545, and diagnostics
18080/18081/18082. The node runtime used a Linux /tmp directory so chmod 600 works.
The earlier setup attempt failed because WSL's Windows mount could not enforce the
required development-key permissions; its logs are retained in earlier-setup-failure/.
The next historical-check attempt stopped before comparison because solc 0.8.28
was absent in offline mode. Foundry installed the pinned compiler, after which the
check was rerun. historical-offline-failure.log and attempt-before-solc-install.json
retain this failure; solidity-build.log records the successful offline build.
The test's own processes were stopped after completion; the original demo was preserved.

SHA256SUMS.json authenticates the archived file bytes relative to this directory.
It is an integrity manifest, not independent authentication of who ran the tests.
'''
(run/'README.md').write_text(readme,encoding='utf-8')
files=[f for f in run.rglob('*') if f.is_file() and 'isolated-project' not in f.relative_to(run).parts and 'localnet-runtime' not in f.relative_to(run).parts and f.name!='SHA256SUMS.json']
hashes={str(f.relative_to(run)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
(run/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
archive=run.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for file in files+[run/'SHA256SUMS.json']:z.write(file,arcname=str(file.relative_to(run)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in hashes.items())
print(json.dumps(report,indent=2))
print('ARCHIVE',archive,'SHA256',hashlib.sha256(archive.read_bytes()).hexdigest())
